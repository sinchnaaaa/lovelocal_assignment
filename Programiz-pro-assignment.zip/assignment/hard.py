def shortest_palindrome(s):
    i = 0
    for j in range(len(s) - 1, -1, -1):
        if s[i] == s[j]:
            i += 1

    if i == len(s):
        return s

    suffix = s[i:]
    prefix = suffix[::-1]
    middle = shortest_palindrome(s[:i])

    return prefix + middle + suffix


print(shortest_palindrome("aacecaaa")) 
print(shortest_palindrome("abcd"))  
