def length_of_last_word(s):
    s = s.rstrip()
    length = 0

   
    for char in reversed(s):
       
        if char == ' ' and length > 0:
            break
       
        elif char != ' ':
            length += 1

    return length


print(length_of_last_word("Hello World"))  
print(length_of_last_word("   fly me   to   the moon  ")) 
print(length_of_last_word("luffy is still joyboy"))  
